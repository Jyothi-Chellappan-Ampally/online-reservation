<div class="sidebar">
        <div class="sidebar-dropdown"><a href="#">Navigation</a></div>

       
        <ul id="nav">
       
          <li class="open"><a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
          </li>
         
          
              <li><a href="menu.php"><i class="fa fa-money bgreen"></i>Menu</a></li>
              <li><a href="category.php"><i class="fa fa-file-o"></i>Category</a></li>
              <li><a href="members.php"><i class="fa fa-user"></i>Members</a></li>
                <li><a href="team_members.php"><i class="fa fa-user"></i>Team members</a></li>
                 <li><a href="messages.php"><i class="fa fa-envelope"></i> Messages</a></li> 
                 <li><a href="user.php"><i class="fa fa-user"> </i> User</a></li>
             <li><a href="combo.php"><i class="fa fa-bar-chart-o"></i> Combo</a></li> 
          <li class="has_sub">
      <a href="#"><i class="fa fa-calendar"></i> Reservation  <span class="pull-right"><i class="fa fa-chevron-right"></i></span></a>
            <ul>
               <li><a href="pending.php">Pending Reservations</a></li>
              <li><a href="reservation.php">Confirmed Reservations</a></li>
              <li><a href="finished.php">Finished Reservations</a></li>
             <li><a href="cancelled.php">Cancelled Reservations</a></li>
            </ul>
          </li>  
            <li class="has_sub"><a href="#"><i class="fa fa-bar-chart-o"></i> Inventory</i></span></a>
            <li class="has_sub"><a href="#"><i class="fa fa-bar-chart-o"></i> Report </i></a>
        
        </ul>
    </div>
  